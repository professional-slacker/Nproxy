# nproxy 実装レビューチェックリスト

> このチェックリストは [`08_principles.md`](./08_principles.md) の三原則を実装変更時に守るためのもの。
> **PR / コミット / リリース前**に通すこと。
> **1つでも No があれば設計違反**として変更を差し戻す。

---

## 使い方

1. 変更対象ファイル一覧を眺める
2. 下記 3 群のチェックを順に確認
3. 該当しない項目は N/A、それ以外は Yes/No
4. **No が 1 つでもあれば設計違反として差し戻し**

---

## ✅ Q1. 制御コードはそのまま流れているか

| # | チェック項目 | OK基準 |
|---|---|---|
| 1.1 | byte 層で chunk を Buffer 以外の型に変換していないか | `chunk.toString()` `JSON.parse(chunk)` 等が混入していない |
| 1.2 | ANSI escape sequence を検出・置換するコードを追加していないか | `\x1b` `` `ESC` 等の文字列マッチが本流にない |
| 1.3 | 改行ベースで chunk を分割していないか (text 層を除く) | byte 層で `split('\n')` `indexOf('\n')` が本流にない |
| 1.4 | バイナリ chunk を string 化する経路がないか | byte 層で `setEncoding()` `toString('utf8')` が本流にない |
| 1.5 | text 層で ESC sequence を解釈・除去していないか | TextDecode は StringDecoder の write/end のみ。ESC を検出する処理がない |
| 1.6 | UTF-8 chunk 境界保護が StringDecoder 経由か | 自前で UTF-8 デコードを書いていない |
| 1.7 | TTY raw mode に切り替える処理を入れていないか | `process.stdin.setRawMode(true)` を nproxy 内で呼んでいない |

### 観測機構の例外規定

以下は「観測」なのでOK。ただし**本流には影響しない**こと:

- `chunk.length` の取得
- NORMAL 状態のみの `chunk.slice(0, 16).toString('hex')` (デバッグ用 16 バイトのみ)

---

## ✅ Q2. シグナルは中継されているか

| # | チェック項目 | OK基準 |
|---|---|---|
| 2.1 | SIGINT を親で握りつぶしていないか | `process.on('SIGINT', ...)` 内で `child.kill(sig)` を呼んでいる |
| 2.2 | SIGTERM を親で握りつぶしていないか | 同上 |
| 2.3 | 子のexit code を親が継承しているか | `process.exit(code)` を呼んでいる |
| 2.4 | 子がシグナル終了した場合、親も同じシグナルで終了するか | `process.kill(process.pid, signal)` が走る経路がある |
| 2.5 | child reference を確実に kill する経路があるか | EPIPE 等のエラー時に `child.kill('SIGTERM')` の保険がある |
| 2.6 | zombie プロセスを残す可能性がないか | `child.on('close')` で確実にリソース解放している |
| 2.7 | unhandledRejection / uncaughtException で子を残さないか | プロセス終了時に child.kill が走る fail-safe がある |

### 例外: シグナル中継を意図的に変える場合

将来 `--signal-mode=swallow` や `--signal-mode=protocolize` を導入する際は、
**既定が forward** であることを明示する。CLI で明示指定された場合のみ中継を変える。

---

## ✅ Q3. プロトコル意味付けが nproxy 内に漏れ込んでいないか

| # | チェック項目 | OK基準 |
|---|---|---|
| 3.1 | message framing コードが入っていないか | length-prefix の parser/encoder がない、boundary 検出がない |
| 3.2 | NDJSON / JSON-RPC / multipart の解釈がないか | `JSON.parse(chunk)` が本流にない |
| 3.3 | filename / mimetype / size などの metadata 付与処理がないか | これらの key を作る/読む処理が本流にない |
| 3.4 | サイズ上限を **強制** (拒否) していないか | 観測ログに警告は出しても本流は止めない |
| 3.5 | text 層が「意味」を扱っていないか | TextDecode は decode のみ、Transform は機械的な行加工のみ、tee は string 透過のみ |
| 3.6 | 認証・暗号化・圧縮を nproxy 内で行っていないか | これらは外部の責務 |
| 3.7 | retry / 再接続ロジックがないか | nproxy は単発の中継のみ |
| 3.8 | アプリ依存の設定 (LLM endpoint 等) を読み込んでいないか | nproxy の env 変数は I/O 制御だけに限る (NPROXY_*) |

### 「外側」に出すべきものリスト

迷ったら以下は**必ず外側**:

- `*.proto`, `*.json`, `*.yaml` などのスキーマ定義
- HTTP / WebSocket / gRPC / S3 などの transport
- LLM API / DB クエリ / authn/authz
- ファイル形式 (PDF / PPTX / DOCX) の扱い
- 進捗バー / TTY UX / spinners

---

## ✅ Q4. パフォーマンス退行チェック (補助)

原則①〜③を守った上で、性能基準も維持する。

| # | チェック項目 | 基準 (Win11 / Node v12.9.1) |
|---|---|---|
| 4.1 | 10GB byte 透過のスループット | ≥ 800 MB/s (basline 1037 MB/s から ±20%) |
| 4.2 | 10GB byte 透過時の heap (max) | ≤ 5 MB (baseline 2.7 MB から +α) |
| 4.3 | 10GB ASCII text passthrough のスループット | ≥ 500 MB/s (baseline 633 MB/s から ±20%) |
| 4.4 | 10GB ASCII text passthrough の heap (max) | ≤ 30 MB (baseline 19.4 MB から +α) |
| 4.5 | UTF-8 chunk 境界破壊検知テスト (T5) | byteIntegrity = true 必須 |
| 4.6 | PRESSURE 状態遷移テスト (T9) | 動作することを確認 |
| 4.7 | 既存 6 ケース機能テスト (run_tests.js) | 全 PASS |
| 4.8 | 9 ケース Text I/O テスト (run_text_tests.js) | 全 PASS (T4/T8 の +1〜2byte は許容) |

---

## ✅ Q5. 言語移植時 (Rust / Go / Zig) の追加観点

該当する移植 PR でのみチェック。

| # | チェック項目 | OK基準 |
|---|---|---|
| 5.1 | 本流 I/O が言語標準の **copy** プリミティブか | Rust: `tokio::io::copy`, Go: `io.Copy` など |
| 5.2 | 自前のリングバッファ・チャネルで chunk を経由していないか | OS poll のみで完結している |
| 5.3 | signal handler が main thread / runtime に正しく統合されているか | Rust: `tokio::signal` |
| 5.4 | プロトコル系 crate / package を依存に入れていないか | `tokio_util::codec` 等が本流に存在しない |
| 5.5 | 同一テストデータで Node 版と挙動一致 (6+9 ケース) | run_tests / run_text_tests 互換 |

---

## レビュー結果テンプレ (PR 本文に貼る)

```markdown
## nproxy Review Checklist

### Q1. 制御コードはそのまま流れているか
- [ ] 1.1 chunk を Buffer 以外に変換していない
- [ ] 1.2 ANSI escape を検出・置換していない
- [ ] 1.3 改行ベースの分割を byte 層で行っていない
- [ ] 1.4 byte 層で string 化していない
- [ ] 1.5 text 層で ESC を解釈していない
- [ ] 1.6 UTF-8 デコードは StringDecoder 経由
- [ ] 1.7 TTY raw mode に触っていない

### Q2. シグナルは中継されているか
- [ ] 2.1 SIGINT を握りつぶしていない
- [ ] 2.2 SIGTERM を握りつぶしていない
- [ ] 2.3 exit code を継承している
- [ ] 2.4 シグナル終了を伝播している
- [ ] 2.5 child kill のフェイルセーフがある
- [ ] 2.6 zombie を残さない
- [ ] 2.7 例外時も child を確実に終了させる

### Q3. プロトコル意味付けが漏れ込んでいないか
- [ ] 3.1 framing コードがない
- [ ] 3.2 JSON 解釈がない
- [ ] 3.3 metadata 付与がない
- [ ] 3.4 サイズ上限を強制していない
- [ ] 3.5 text 層が意味を扱っていない
- [ ] 3.6 認証/暗号化/圧縮がない
- [ ] 3.7 retry がない
- [ ] 3.8 アプリ設定を読んでいない

### Q4. 性能基準
- [ ] 10GB byte 透過 ≥ 800 MB/s
- [ ] 10GB byte heap ≤ 5MB
- [ ] 10GB ASCII text ≥ 500 MB/s
- [ ] 10GB ASCII text heap ≤ 30MB
- [ ] T5 byteIntegrity = true
- [ ] T9 PRESSURE 縮退動作
- [ ] 既存 6+9 ケース PASS

### Q5. 移植時のみ (該当する場合)
- [ ] 標準 copy プリミティブ使用
- [ ] OS poll のみで完結
- [ ] signal API 統合
- [ ] プロトコル crate なし
- [ ] Node 版と互換テスト PASS
```

---

## 失敗例 (Anti-pattern)

過去・未来の "nproxy を壊す" 典型パターン:

```js
// ❌ NG: data イベントで chunk を保持
child.stdout.on('data', (chunk) => {
  buffer += chunk.toString();   // 1.4 違反 / Q3 違反
});

// ❌ NG: ANSI を消す
const stripped = chunk.toString().replace(/\x1b\[[0-9;]*m/g, '');  // 1.2 違反

// ❌ NG: SIGINT を握りつぶす
process.on('SIGINT', () => {});  // 2.1 違反

// ❌ NG: framing を nproxy 内に
function parseFrame(chunk) { /* length-prefix parser */ }  // 3.1 違反

// ❌ NG: サイズ強制
if (totalBytes > MAX) { child.kill(); }  // 3.4 違反
```

```js
// ✅ OK: pipe で透過
child.stdout.pipe(process.stdout);

// ✅ OK: メタだけ観測
const orig = process.stdout.write.bind(process.stdout);
process.stdout.write = (chunk, ...rest) => {
  Observer.onChunk('out', chunk.length);   // size のみ
  return orig(chunk, ...rest);             // chunk は触らない
};

// ✅ OK: シグナル中継
process.on('SIGINT', () => child.kill('SIGINT'));

// ✅ OK: 観測としてのサイズ警告
if (totalBytes > WARN_THRESHOLD) dlog('[WARN] large transfer');  // ログのみ
```

---

## 改訂履歴

| 日付 | 内容 |
|---|---|
| 2026-05-08 | 初版作成 |
